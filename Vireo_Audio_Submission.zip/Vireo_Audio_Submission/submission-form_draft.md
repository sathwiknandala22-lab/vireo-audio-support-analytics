# Submission Form — Draft

> The exact `submission-form.md` was not present in the uploaded pack, so this is a draft and should be copied into the client's form if/when supplied.

**Deliverable:** Vireo Audio — Support Tickets (Set B)

**Working tool:** `app.py` (Streamlit)

**Business goal:** Reduce replacement rate from **22.1% in 2026 H1 to 15%**, representing about **₹337,929/quarter** at the H1 ticket run-rate and observed policy replacement cost.

**Validation:** deterministic data checks; local text classifier **78.3% held-out accuracy**; queue-adjusted review check MAE ≈ **0.82 CSAT points**.

**AI used:** ChatGPT for development/analysis/prompt design; local scikit-learn TF-IDF + logistic regression at runtime.

**Runtime model cost:** ₹0 recurring API cost.

**Scope decision:** Tier 2 agents are not ranked against Tier 1; bottom ten is a review queue, not automatic retraining.
